var inputs = document.querySelector("#inp");
var btn = document.querySelector("#text");

function Add(){
    if(inputs.value == ""){
        alert("please enter task");
    }else {
        var newEle =document.createElement("ul");
        newEle.innerHTML = `${inputs.value} <i class="ri-delete-bin-6-line"></i>`;
        text.appendChild(newEle);
        inputs.value ="";
        newEle.querySelector("i").addEventListener("click", remove)
        function remove(){
            newEle.remove();
        }
    }
}